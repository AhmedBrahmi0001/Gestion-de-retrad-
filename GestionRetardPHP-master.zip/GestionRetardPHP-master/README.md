# GestionRetardPHP
PHP|MYSQL
employees fait checkIn lorsqu'il arrive a la societe et checkout s'il arrive en retard doit decrire la cause de retard admin gerer les employees et consulter la liste de retard et peut l'envoyer email 
