<?php
session_start();

/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 28/01/2020
 * Time: 23:52
 */
header("location:LoginFormAdmin/Login.php");
session_destroy();
?>