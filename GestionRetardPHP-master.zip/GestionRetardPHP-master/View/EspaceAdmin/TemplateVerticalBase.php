



        <div class="logo">

            <label class="simple-text logo-normal">
                Espace Admin

            </label>

        </div>
        <div class="sidebar-wrapper">
            <ul class="nav">
                <li class="nav-item active ">
                    <a class="nav-link" href="AdminProfile.php">
                        <i class="material-icons">person</i>
                        <p>Admin Profile</p>
                    </a>
                </li>
                <li class="nav-item  ">
                    <a class="nav-link" href="AjoutEmployee.php"><!-- ./dashboard.html   -->
                        <i class="material-icons">dashboard</i>
                        <p>Ajouter un Employee</p>
                    </a>
                </li>

                <li class="nav-item ">
                    <a class="nav-link" href="ListEmployee.php"><!--  table.html-->
                        <i class="material-icons">content_paste</i>
                        <p>Liste Des Employee</p>
                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="ListeEmployeeEnRetard.php"><!--  table.html-->
                        <i class="material-icons">content_paste</i>
                        <p>Liste Des Retard</p>
                    </a>
                </li>


            </ul>
        </div>


<!--   Core JS Files   -->



