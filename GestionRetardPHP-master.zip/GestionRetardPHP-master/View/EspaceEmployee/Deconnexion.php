<?php
session_start();
session_destroy();
/**
 * Created by PhpStorm.
 * User: ASUS
 * Date: 28/01/2020
 * Time: 22:34
 */
header("location:LoginFromEmployee/pages-login.php");

?>